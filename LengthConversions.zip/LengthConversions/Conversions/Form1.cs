using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Conversions
{
    public partial class Form1 : Form
    {
        public static decimal units;
        public static decimal conversion;
        public static decimal conversionRate;
        public Form1()
        {
            InitializeComponent();
        }
        
        string[,] conversionTable = {
			{"Miles to Kilometers", "Miles", "Kilometers", "1.6093"},
			{"Kilometers to miles", "Kilometers", "Miles", "0.6214"},
			{"Feet to meters", "Feet", "Meters", "0.3048"},
			{"Meters to feet", "Meters", "Feet", "3.2808"},
			{"Inches to centimeters", "Inches", "Centimeters", "2.54"},
			{"Centimeters to inches", "Centimeters", "Inches", "0.3937"}
		};
        public bool IsValidData()
        {


            return true;
        }
        public bool IsPresent(TextBox textBox, string name)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(name + " is a required field.", "Entry Error");
                textBox.Focus();
                return false;
            }
            return true;
        }

        public bool IsDecimal(TextBox textBox, string name)
        {
            try
            {
                Convert.ToDecimal(textBox.Text);
                return true;
            }
            catch (FormatException)
            {
                MessageBox.Show(name + " must be a decimal number.", "Entry Error");
                textBox.Focus();
                return false;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            
            if (conversionTable[0, 0] == cboConversions.Text)
            {
                units = Convert.ToDecimal(lblFromLength.Text);
                conversion = Convert.ToDecimal(conversionTable[0, 3]) * units;
                lblCalculatedLength.Text = Convert.ToString(conversion);
            }
            else if (conversionTable[1, 0] == cboConversions.Text)
            {
                conversion = Convert.ToDecimal(conversionTable[0, 3]) * units;
                lblCalculatedLength.Text = Convert.ToString(conversion);
            }
            else if (conversionTable[2, 0] == cboConversions.Text)
            {
                conversion = Convert.ToDecimal(conversionTable[0, 3]) * units;
                lblCalculatedLength.Text = Convert.ToString(conversion);
            }
            else if (conversionTable[3, 0] == cboConversions.Text)
            {
                conversion = Convert.ToDecimal(conversionTable[0, 3]) * units;
                lblCalculatedLength.Text = Convert.ToString(conversion);
            }
            else if (conversionTable[4, 0] == cboConversions.Text)
            {
                conversion = Convert.ToDecimal(conversionTable[0, 3]) * units;
                lblCalculatedLength.Text = Convert.ToString(conversion);
            }
            else if (conversionTable[5, 0] == cboConversions.Text)
            {
                conversion = Convert.ToDecimal(conversionTable[0, 3]) * units;
                lblCalculatedLength.Text = Convert.ToString(conversion);
            }
        }
        private void ChkChanged(object sender, EventArgs e)
        {
            try
            {


                if (cboConversions.Text == "Miles to Kilometers")
                {
                    lblFromLength.Text = "Miles:";
                    lblToLength.Text = "Kilometers:";
                }
                else if (cboConversions.Text == "Kilometers to Miles")
                {
                    lblFromLength.Text = "Kilometers:";
                    lblToLength.Text = "Miles:";
                }
                else if (cboConversions.Text == "Feet to Meters")
                {
                    lblFromLength.Text = "Feet:";
                    lblToLength.Text = "Meters:";
                }
                else if (cboConversions.Text == "Meters to Feet")
                {
                    lblFromLength.Text = "Meters:";
                    lblToLength.Text = "Feet:";
                }
                else if (cboConversions.Text == "Inches to Centimeters")
                {
                    lblFromLength.Text = "Inches:";
                    lblToLength.Text = "Centimeters:";
                }
                else if (cboConversions.Text == "Centimeters to Inches")
                {
                    lblFromLength.Text = "Centimeters:";
                    lblToLength.Text = "Inches:";
                }
            }
            catch (Exception)
            {
                MessageBox.Show("How did you get here??","seriously, how?");
            }
        }

        
    }
}